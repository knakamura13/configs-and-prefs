Thank you for licensing fonts from I Love Typography!

Here are a few useful links:

Download link: https://fonts.ilovetypography.com/account/orders#ILT-220509-cc2ea3c
ILT Terms & Conditions: https://fonts.ilovetypography.com/terms-conditions

ILT help pages for advice on how to install fonts and other frequently
asked questions: https://help.ilovetypography.com/

We also recommend that you check your Dashboard to get the latest news
(and font updates) from foundries you license from and follow:
https://fonts.ilovetypography.com/account

Finally, stay in touch and up to date by following us on
Twitter @ilovetypography and on Instagram @ilovetypography_

Thanks and see you soon!

Nadine, John, & Julia
https://ilovetypography.com/